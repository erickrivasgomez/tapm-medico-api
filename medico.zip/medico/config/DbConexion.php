<?php
 
class DbConexion
{
    //Variable a contener el link de acceso a la BD
    private $con;
 
    //Class constructor
    function __construct()
    {
 
    }
 
    //Este metodo debera conectarse con la base de datos
    function conectar()
    {
        //Incluyendo la clase constantes.php se tomaran las variables de acceso a la BD
        include_once dirname(__FILE__) . '/constantes.php';
 
        //lINEA de conexion con MySQL
        $this->con = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
        //Aqui verificamos que no exita un error con la conexion
        if (mysqli_connect_errno()) {
            echo "Falla en la conexion a MySQL: " . mysqli_connect_error();
            return null;
        }
 
        //Finalmente devuelve la cadena o link de conexion
        return $this->con;
    }
 
}

?>