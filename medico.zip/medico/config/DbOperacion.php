
<?php

class DbOperacion
{
    private $con;

    public function __construct()
    {
        require_once dirname(__FILE__) . '/DbConexion.php';
        $db = new DbConexion();
        $this->con = $db->conectar();
    }

    //adding a record to database
    public function agregarUsuario($nombre, $email, $password)
    {
        $stmt = $this->con->prepare("INSERT INTO pacientes (nombre, email, password) VALUES (?, ?, md5(?))");
        $stmt->bind_param("sss", $nombre, $email, $password);
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    //Valida al usuario
    public function iniciarSesion($username, $password)
    {
        $stmt = $this->con->prepare("SELECT id, nombre FROM pacientes WHERE email=? AND password=md5(?)");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $stmt->bind_result($id, $nombre);
        $usuario = array();

        while ($stmt->fetch()) {
            $temp = array();
            $temp['id'] = $id;
            $temp['nombre'] = $nombre;
            array_push($usuario, $temp);
        }
        return $usuario;
    }

    //fetching all records from the database
    public function obtenerCitasMedico($id_medico)
    {
        $stmt = $this->con->prepare('SELECT * FROM citas where id_doctor = ?;');
        $stmt->bind_param("i", $id_medico);
        $stmt->execute();
        $stmt->bind_result($id, $id_medico, $id_paciente, $id_horario, $fecha, $activa, $c_at, $u_at);
        $citas = array();

        while ($stmt->fetch()) {
            $temp = array();
            $temp['id'] = $id;
            $temp['id_medico'] = $id_medico;
            $temp['id_paciente'] = $id_paciente;
            $temp['id_horario'] = $id_horario;
            $temp['fecha'] = $fecha;
            $temp['activa'] = $activa;
            array_push($citas, $temp);
        }
        return $citas;
    }

    public function obtenerCitasPaciente($id_paciente)
    {
        $stmt = $this->con->prepare('SELECT * FROM citas inner join horarios on citas.id_horario = horarios.id where id_paciente = ?;');
        $stmt->bind_param("i", $id_paciente);
        $stmt->execute();
        $stmt->bind_result($id, $id_medico, $id_paciente, $id_horario, $fecha, $activa, $horario_id, $hora, $agendar_antes_de);
        $citas = array();

        while ($stmt->fetch()) {
            $temp = array();
            $temp['id'] = $id;
            $temp['id_usuario'] = $id_medico;
            $temp['id_paciente'] = $id_paciente;
            $temp['id_horario'] = $id_horario;
            $temp['hora'] = $hora;
            $temp['fecha'] = $fecha;
            $temp['activa'] = $activa;
            array_push($citas, $temp);
        }
        return $citas;
    }

    public function obtenerHora($fecha)
    {
        if (date($fecha) != date("Y-m-d")) {
            $citas = array();
            $temp["mensaje"] = "Dias iguales";
            array_push($citas, $temp);
            return $citas;
        } else {
            $citas = array();
            $temp["mensaje"] = "Dias no iguales";
            array_push($citas, $temp);
            return $citas;
        }
    }

    public function agregarCita($id_paciente, $id_doctor, $hora, $fecha, $activa)
    {
        $id_horario = null;
        $agendar_antes_de = null;
        $id_cita = null;

        $stmt = $this->con->prepare('SELECT id, agendar_antes_de FROM horarios where hora_inicio = ?;');
        $stmt->bind_param("s", $hora);
        $stmt->execute();
        $stmt->bind_result($id, $agendar_antes);
        $citas = array();
        while ($stmt->fetch()) {
            $id_horario = $id;
            $agendar_antes_de = $agendar_antes;
        }
        if (!$id_horario) {
            return 1;
        }

        $stmt = $this->con->prepare('SELECT id FROM citas where fecha = ? and id_horario = ? ;');
        $stmt->bind_param("si", $fecha, $id_horario);
        $stmt->execute();
        $stmt->bind_result($id);
        $citas = array();
        while ($stmt->fetch()) {
            $id_cita = $id;
        }
        if ($id_cita) {
            return 2;
        } else {
            if (!(date("Y-m-d H:i:s") < date($fecha . " " . $agendar_antes_de))) {
                return 3;
            } else {
                $stmt = $this->con->prepare('INSERT INTO citas (id_paciente,id_doctor,id_horario,fecha,activa) values (?,?,?,?,?)');
                $stmt->bind_param("iiisi", $id_paciente, $id_doctor, $id_horario, $fecha, $activa);
                if ($stmt->execute()) {
                    return 4;
                }
                return 5;
            }
        }
    }
}

// id11382343_medico 	id11382343_lfao

?>
