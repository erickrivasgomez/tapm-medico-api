<?php

 define('DB_HOST','');
 define('DB_NAME', '');
 define('DB_USERNAME','');
 define('DB_PASSWORD',''); // Aqui va el password de tu DB

 ?>
