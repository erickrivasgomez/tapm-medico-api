<?php



//adding DbOperacion file

require_once dirname(__FILE__) . '/config/DbOperacion.php';



//response array

$response = array();



//if a get parameter named op is set we will consider it as an api call

if (isset($_GET['accion'])) {



    //switching the get op value

    switch ($_GET['accion']) {



        case 'agregarUsuario':

            if (isset($_POST['nombre']) && isset($_POST['email']) && isset($_POST['password'])) {

                $db = new DbOperacion();

                if ($db->agregarUsuario($_POST['nombre'], $_POST['email'], $_POST['password'])) {

                    $response['error'] = false;

                    $response['message'] = 'El usuario se ha agregado correctamente';

                } else {

                    $response['error'] = true;

                    $response['message'] = 'Ocurrio un error al intentar agregar al usuario';

                }

            } else {

                $response['error'] = true;

                $response['message'] = 'Los parametros estan incompletos';

            }

            break;



        case 'iniciarSesion':

            if (isset($_POST['email']) && isset($_POST['password'])) {

                $db = new DbOperacion();

                $usuario = $db->iniciarSesion($_POST['email'], $_POST['password']);

                if (count($usuario) <= 0) {

                    $response['error'] = true;

                    $response['message'] = 'Usuario no valido';

                } else {

                    $response['error'] = false;

                    $response['message'] = 'Sesion iniciada Correctamente';

                    $response['usuario'] = $usuario;

                }

            } else {

                $response['error'] = true;

                $response['message'] = 'Los parametros estan incompletos';

            }

            break;



        case 'obtenerCitasMedico':

            if (isset($_POST['id_medico'])) {

                $db = new DbOperacion();

                $citas = $db->obtenerCitasMedico(intval($_POST['id_medico']));

                if (count($citas) <= 0) {

                    $response['error'] = true;

                    $response['message'] = 'id_medico no valido';

                } else {

                    $response['error'] = false;

                    $response['message'] = 'Citas obtenidas Correctamente';

                    $response['usuario'] = $citas;

                }

            } else {

                $response['error'] = true;

                $response['message'] = 'Los parametros estan incompletos';

            }

            break;



        case 'obtenerCitasPaciente':

            if (isset($_POST['id_paciente'])) {

                $db = new DbOperacion();

                $citas = $db->obtenerCitasPaciente(intval($_POST['id_paciente']));

                if (count($citas) <= 0) {

                    $response['error'] = true;

                    $response['message'] = 'No hay citas para este paciente';

                } else {

                    $response['error'] = false;

                    $response['message'] = 'Citas obtenidas Correctamente';

                    $response['citas'] = $citas;

                }

            } else {

                $response['error'] = true;

                $response['message'] = 'Los parametros estan incompletos';

            }

            break;



        case 'agregarCita':

            if (

                isset($_POST['id_paciente']) &&

                isset($_POST['id_doctor']) &&

                isset($_POST['hora']) &&

                isset($_POST['fecha']) &&

                isset($_POST['activa'])

            ) {

                $db = new DbOperacion();

                $resultado = $db->agregarCita($_POST['id_paciente'], $_POST['id_doctor'], $_POST['hora'], $_POST['fecha'], $_POST['activa']);

                switch ($resultado) {

                    case 1:

                        $response['error'] = true;

                        $response['message'] = "Horario no válido";

                        break;

                    case 2:

                        $response['error'] = true;

                        $response['message'] = "Horario no disponible";

                        break;

                    case 3:

                        $response['error'] = true;

                        $response['message'] = "Horario no válido. Se debe agendar con al menos 2 horas de anticipación.";

                        break;

                    case 4:

                        $response['error'] = false;

                        $response['message'] = "Cita agendada correctamente.";

                        break;

                    default:

                        $response['error'] = true;

                        $response['message'] = "Error al insertar";

                        break;

                }

            } else {

                $response['error'] = true;

                $response['message'] = 'Los parametros estan incompletos';

            }

            break;


        default:

            $response['error'] = true;

            $response['message'] = 'Operación no válida ';

    }

} else {

    $response['error'] = false;

    $response['message'] = 'Peticion Invalida';

}



//displaying the data in json

echo json_encode($response);

